package com.example.snake;

import javafx.scene.input.KeyCode;
import java.awt.*;
import java.util.List;

public class SnakeGame {
    private Snake snake;
    private Food food;
    private GameBoard gameBoard;
    private int currentDirection;
    private boolean gameOver;
    private int score = 0;
    private static final int RIGHT = 0;
    private static final int LEFT = 1;
    private static final int UP = 2;
    private static final int DOWN = 3;

    public SnakeGame(int rows, int columns) {
        this.snake = new Snake(rows);
        this.gameBoard = new GameBoard(rows, columns);
        generateFood();
    }
    public Snake getSnake() {
        return snake;
    }
    public Food getFood(){
        return food;
    }
    public GameBoard getGameBoard() {
        return gameBoard;
    }

    public void moveSnake() {
        List<Point> snakeBody = snake.getSnakeBody();
        for (int i = snakeBody.size() - 1; i >= 1; i--) {
            snakeBody.get(i).x = snakeBody.get(i - 1).x;
            snakeBody.get(i).y = snakeBody.get(i - 1).y;
        }

        switch (currentDirection) {
            case RIGHT:
                moveRight();
                break;
            case LEFT:
                moveLeft();
                break;
            case UP:
                moveUp();
                break;
            case DOWN:
                moveDown();
                break;
        }

        gameOver();
        eatFood();
    }


    public void setDirection(KeyCode code) {
        if (code == KeyCode.RIGHT || code == KeyCode.D) {
            if (currentDirection != LEFT) {
                currentDirection = RIGHT;
            }
        } else if (code == KeyCode.LEFT || code == KeyCode.A) {
            if (currentDirection != RIGHT) {
                currentDirection = LEFT;
            }
        } else if (code == KeyCode.UP || code == KeyCode.W) {
            if (currentDirection != DOWN) {
                currentDirection = UP;
            }
        } else if (code == KeyCode.DOWN || code == KeyCode.S) {
            if (currentDirection != UP) {
                currentDirection = DOWN;
            }
        }
    }

    public void generateFood() {
        start:
        while (true) {
            int foodX = (int) (Math.random() * gameBoard.getRows());
            int foodY = (int) (Math.random() * gameBoard.getColumns());

            for (Point snakePart : snake.getSnakeBody()) {
                if (snakePart.getX() == foodX && snakePart.getY() == foodY) {
                    continue start;
                }
            }

            food = new Food(foodX, foodY);
            break;
        }
    }

    public boolean isGameOver() {
        return gameOver;
    }

    public int getScore() {
        return score;
    }

    private void moveRight() {
        Point snakeHead = snake.getSnakeHead();
        snakeHead.x++;
        if (snakeHead.x >= gameBoard.getRows()) {
            gameOver = true;
        }
    }

    private void moveLeft() {
        Point snakeHead = snake.getSnakeHead();
        snakeHead.x--;
        if (snakeHead.x < 0) {
            gameOver = true;
        }
    }

    private void moveUp() {
        Point snakeHead = snake.getSnakeHead();
        snakeHead.y--;
        if (snakeHead.y < 0) {
            gameOver = true;
        }
    }

    private void moveDown() {
        Point snakeHead = snake.getSnakeHead();
        snakeHead.y++;
        if (snakeHead.y >= gameBoard.getColumns()) {
            gameOver = true;
        }
    }

    private void eatFood() {
        Point snakeHead = snake.getSnakeHead();
        if (snakeHead.getX() == food.getX() && snakeHead.getY() == food.getY()) {
            snake.addBodyPart(new Point((int) snakeHead.getX(), (int) snakeHead.getY()));
            score++;
            generateFood();
        }
    }


    private void gameOver() {
        Point snakeHead = snake.getSnakeHead();
        List<Point> snakeBody = snake.getSnakeBody();

        for (int i = 1; i < snakeBody.size(); i++) {
            if (snakeHead.getX() == snakeBody.get(i).getX() && snakeHead.getY() == snakeBody.get(i).getY()) {
                gameOver = true;
                break;
            }
        }

    }
}