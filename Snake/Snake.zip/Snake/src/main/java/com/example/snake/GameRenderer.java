package com.example.snake;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import java.awt.*;

public class GameRenderer {
    private SnakeGame game;
    private GraphicsContext gc;
    private Canvas canvas;
    private int cellSize;

    // Constructor that takes in a SnakeGame object and the cell size for the game board
    public GameRenderer(SnakeGame game, int cellSize) {
        this.game = game;
        this.cellSize = cellSize;

        // Initialize the canvas with the appropriate size
        int canvasWidth = game.getGameBoard().getRows() * cellSize;
        int canvasHeight = game.getGameBoard().getColumns() * cellSize;
        this.canvas = new Canvas(canvasWidth, canvasHeight);

        // Initialize the graphics context for the canvas
        this.gc = canvas.getGraphicsContext2D();
    }

    // Getter method for the canvas
    public Canvas getCanvas() {
        return canvas;
    }

    // Method to render the game on the canvas
    public void render() {
        // Clear the canvas before rendering
        gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());

        // Draw the background, snake, and food on the canvas
        drawBackground();
        drawSnake();
        drawFood();
    }

    // Private helper method to draw the snake on the canvas
    private void drawSnake() {
        gc.setFill(Color.DARKGREEN);
        gc.setStroke(Color.BLACK);
        gc.setLineWidth(1);

        // Iterate through each body part of the snake and draw it on the canvas
        for (Point bodyPart : game.getSnake().getSnakeBody()) {
            gc.fillRect(bodyPart.getX() * cellSize, bodyPart.getY() * cellSize, cellSize, cellSize);
            gc.strokeRect(bodyPart.getX() * cellSize, bodyPart.getY() * cellSize, cellSize, cellSize);
        }
    }

    // Private helper method to draw the food on the canvas
    private void drawFood() {
        gc.setFill(Color.RED);
        gc.setStroke(Color.BLACK);
        gc.setLineWidth(1);

        // Get the position of the food and draw it on the canvas
        int foodX = game.getFood().getX();
        int foodY = game.getFood().getY();
        gc.fillRect(foodX * cellSize, foodY * cellSize, cellSize, cellSize);
        gc.strokeRect(foodX * cellSize, foodY * cellSize, cellSize, cellSize);
    }

    // Private helper method to draw the background on the canvas
    private void drawBackground() {
        Color lightGreen = Color.rgb(170, 215, 81);
        Color darkGreen = Color.rgb(162, 209, 73);

        // Iterate through each cell in the game board and draw the appropriate background color on the canvas
        for (int row = 0; row < game.getGameBoard().getRows(); row++) {
            for (int col = 0; col < game.getGameBoard().getColumns(); col++) {
                gc.setFill((row + col) % 2 == 0 ? lightGreen : darkGreen);
                gc.fillRect(row * cellSize, col * cellSize, cellSize, cellSize);
            }
        }
    }
}