package com.example.snake;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Snake {
    private List<Point> snakeBody = new ArrayList<Point>();
    private Point snakeHead;

    // Constructor that takes in the number of rows in the game board
    public Snake(int rows) {
        // Initialize the snake with three body parts in the middle row of the game board
        for (int i = 0; i < 3; i++) {
            snakeBody.add(new Point(5, rows / 2));
        }
        // Set the head of the snake to be the first body part in the list
        snakeHead = snakeBody.get(0);
    }

    // Getter method for the snake body
    public List<Point> getSnakeBody() {
        return snakeBody;
    }

    // Getter method for the snake head
    public Point getSnakeHead() {
        return snakeHead;
    }

    // Method to add a body part to the snake
    public void addBodyPart(Point point) {
        snakeBody.add(point);
    }
}
