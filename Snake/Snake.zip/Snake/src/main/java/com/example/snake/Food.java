package com.example.snake;
public class Food {
    private int x;
    private int y;

    // Constructor that takes in the initial x and y coordinates of the food
    public Food(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // Getter method for x coordinate
    public int getX() {
        return x;
    }

    // Getter method for y coordinate
    public int getY() {
        return y;
    }

    // Setter method for x coordinate
    public void setX(int x) {
        this.x = x;
    }

    // Setter method for y coordinate
    public void setY(int y) {
        this.y = y;
    }
}